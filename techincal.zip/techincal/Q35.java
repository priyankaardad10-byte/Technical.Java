import java.util.Scanner;

public class Q35 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        String sentence = inputScanner.nextLine().toLowerCase();

        int vowelCount = 0;
        int consonantCount = 0;

        for (int i = 0; i < sentence.length(); i++) {

            char character = sentence.charAt(i);

            if (character >= 'a' && character <= 'z') {

                if (character == 'a' || character == 'e' || character == 'i' || character == 'o' || character == 'u') {
                    vowelCount++;
                } else {
                    consonantCount++;
                }
            }
        }

        System.out.println(vowelCount);
        System.out.println(consonantCount);
    }
}