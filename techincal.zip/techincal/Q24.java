public class Q24 {
    public static void main(String[] args) {

        for (char alphabet = 'A'; alphabet <= 'Z'; alphabet++) {
            System.out.print(alphabet + " ");
        }
    }
}