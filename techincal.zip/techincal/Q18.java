import java.util.Scanner;

public class Q18 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int n = inputScanner.nextInt();

        int sum = n * (n + 1) / 2;

        System.out.println(sum);
    }
}