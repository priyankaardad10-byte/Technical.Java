import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        float firstNumber = inputScanner.nextFloat();
        float secondNumber = inputScanner.nextFloat();
        float product = firstNumber * secondNumber;
        System.out.println(product);
    }
}