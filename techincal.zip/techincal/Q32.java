import java.util.Scanner;

public class Q32 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int start = inputScanner.nextInt();
        int end = inputScanner.nextInt();

        for (int number = start; number <= end; number++) {

            int originalNumber = number;
            int result = 0;
            int temp = number;

            while (temp != 0) {
                int digit = temp % 10;
                result += digit * digit * digit;
                temp /= 10;
            }

            if (result == originalNumber) {
                System.out.print(number + " ");
            }
        }
    }
}