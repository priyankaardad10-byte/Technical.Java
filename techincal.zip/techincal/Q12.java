import java.util.Scanner;

public class Q12 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        String inputString = inputScanner.nextLine();
        String resultString = inputString.replaceAll("\\s", "");
        System.out.println(resultString);
    }
}