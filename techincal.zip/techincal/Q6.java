import java.util.Scanner;

public class Q6 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int firstNumber = inputScanner.nextInt();
        int secondNumber = inputScanner.nextInt();
        int temporaryValue = firstNumber;
        firstNumber = secondNumber;
        secondNumber = temporaryValue;
        System.out.println(firstNumber);
        System.out.println(secondNumber);
    }
}