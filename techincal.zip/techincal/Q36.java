import java.util.Arrays;
import java.util.Scanner;

public class Q36 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);

        int size = inputScanner.nextInt();
        inputScanner.nextLine();

        String[] words = new String[size];

        for (int i = 0; i < size; i++) {
            words[i] = inputScanner.nextLine();
        }

        Arrays.sort(words);

        for (String word : words) {
            System.out.println(word);
        }
    }
}