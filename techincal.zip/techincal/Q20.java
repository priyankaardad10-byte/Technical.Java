import java.util.Scanner;

public class Q20 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int number = inputScanner.nextInt();

        for (int i = 1; i <= 10; i++) {
            System.out.println(number * i);
        }
    }
}