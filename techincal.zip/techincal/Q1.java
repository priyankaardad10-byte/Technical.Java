import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int userNumber = inputScanner.nextInt();
        System.out.println(userNumber);
    }
}