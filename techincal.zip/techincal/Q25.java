import java.util.Scanner;

public class Q25 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int number = inputScanner.nextInt();

        int digitCount = 0;

        while (number != 0) {
            number /= 10;
            digitCount++;
        }

        System.out.println(digitCount);
    }
}