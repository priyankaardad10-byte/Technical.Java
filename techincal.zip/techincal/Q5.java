import java.util.Scanner;

public class Q5 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int dividend = inputScanner.nextInt();
        int divisor = inputScanner.nextInt();
        int quotient = dividend / divisor;
        int remainder = dividend % divisor;
        System.out.println(quotient);
        System.out.println(remainder);
    }
}