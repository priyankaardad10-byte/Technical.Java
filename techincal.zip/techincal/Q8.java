import java.util.Scanner;

public class Q8 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        char alphabet = Character.toLowerCase(inputScanner.next().charAt(0));

        if (alphabet == 'a' || alphabet == 'e' || alphabet == 'i' || alphabet == 'o' || alphabet == 'u') {
            System.out.println("Vowel");
        } else {
            System.out.println("Consonant");
        }
    }
}