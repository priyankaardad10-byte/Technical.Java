import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int firstNumber = inputScanner.nextInt();
        int secondNumber = inputScanner.nextInt();
        int sum = firstNumber + secondNumber;
        System.out.println(sum);
    }
}