import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        char inputCharacter = inputScanner.next().charAt(0);
        int asciiValue = inputCharacter;
        System.out.println(asciiValue);
    }
}