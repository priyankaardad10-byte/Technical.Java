import java.util.Scanner;

public class Q27 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int base = inputScanner.nextInt();
        int exponent = inputScanner.nextInt();

        long result = 1;

        for (int i = 1; i <= exponent; i++) {
            result *= base;
        }

        System.out.println(result);
    }
}