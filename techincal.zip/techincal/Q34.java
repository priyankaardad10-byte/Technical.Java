import java.util.Scanner;

public class Q34 {
    public static void main(String[] args) {

        Scanner inputScanner = new Scanner(System.in);

        System.out.print("Enter first number: ");
        double firstNumber = inputScanner.nextDouble();

        System.out.print("Enter operator (+, -, *, /): ");
        char operator = inputScanner.next().charAt(0);

        System.out.print("Enter second number: ");
        double secondNumber = inputScanner.nextDouble();

        double result;

        switch (operator) {

            case '+':
                result = firstNumber + secondNumber;
                System.out.println("Result = " + result);
                break;

            case '-':
                result = firstNumber - secondNumber;
                System.out.println("Result = " + result);
                break;

            case '*':
                result = firstNumber * secondNumber;
                System.out.println("Result = " + result);
                break;

            case '/':
                if (secondNumber == 0) {
                    System.out.println("Cannot divide by zero");
                } else {
                    result = firstNumber / secondNumber;
                    System.out.println("Result = " + result);
                }
                break;

            default:
                System.out.println("Invalid Operator");
        }

        inputScanner.close();
    }
}