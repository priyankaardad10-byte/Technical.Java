import java.util.Scanner;

public class Q14 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        String inputString = inputScanner.nextLine();

        if (inputString == null || inputString.isEmpty()) {
            System.out.println("Empty or Null");
        } else {
            System.out.println("Not Empty");
        }
    }
}