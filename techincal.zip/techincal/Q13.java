import java.text.DecimalFormat;
import java.util.Scanner;

public class Q13 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        double number = inputScanner.nextDouble();
        int decimalPlaces = inputScanner.nextInt();

        StringBuilder formatPattern = new StringBuilder("#.");
        for (int i = 0; i < decimalPlaces; i++) {
            formatPattern.append("#");
        }

        DecimalFormat decimalFormatter = new DecimalFormat(formatPattern.toString());
        System.out.println(decimalFormatter.format(number));
    }
}