import java.util.Scanner;

public class Q37 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int rows = inputScanner.nextInt();

        for (int i = 1; i <= rows; i++) {

            for (int j = i; j < rows; j++) {
                System.out.print(" ");
            }

            for (int j = 1; j <= (2 * i - 1); j++) {
                System.out.print("*");
            }

            System.out.println();
        }
    }
}