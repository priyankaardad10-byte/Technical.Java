import java.util.Scanner;

public class Q31 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int number = inputScanner.nextInt();

        int originalNumber = number;
        int result = 0;

        while (number != 0) {
            int digit = number % 10;
            result += digit * digit * digit;
            number /= 10;
        }

        if (result == originalNumber) {
            System.out.println("Armstrong");
        } else {
            System.out.println("Not Armstrong");
        }
    }
}