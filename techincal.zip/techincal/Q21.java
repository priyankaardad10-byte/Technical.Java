import java.util.Scanner;

public class Q21 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int terms = inputScanner.nextInt();

        int firstNumber = 0;
        int secondNumber = 1;

        for (int i = 1; i <= terms; i++) {
            System.out.print(firstNumber + " ");
            int nextNumber = firstNumber + secondNumber;
            firstNumber = secondNumber;
            secondNumber = nextNumber;
        }
    }
}