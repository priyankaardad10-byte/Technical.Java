import java.util.Scanner;

public class Q30 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int start = inputScanner.nextInt();
        int end = inputScanner.nextInt();

        for (int number = start; number <= end; number++) {

            boolean isPrime = true;

            if (number <= 1) {
                isPrime = false;
            }

            for (int i = 2; i <= Math.sqrt(number); i++) {
                if (number % i == 0) {
                    isPrime = false;
                    break;
                }
            }

            if (isPrime) {
                System.out.print(number + " ");
            }
        }
    }
}