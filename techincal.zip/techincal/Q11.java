import java.util.Scanner;

public class Q11 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        String inputString = inputScanner.nextLine();
        char targetCharacter = inputScanner.next().charAt(0);

        int frequency = 0;

        for (int index = 0; index < inputString.length(); index++) {
            if (inputString.charAt(index) == targetCharacter) {
                frequency++;
            }
        }

        System.out.println(frequency);
    }
}