import java.util.Scanner;

public class Q9 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        int firstNumber = inputScanner.nextInt();
        int secondNumber = inputScanner.nextInt();
        int thirdNumber = inputScanner.nextInt();

        int largestNumber = Math.max(firstNumber, Math.max(secondNumber, thirdNumber));
        System.out.println(largestNumber);
    }
}