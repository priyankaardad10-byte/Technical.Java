import java.util.Scanner;

public class Q17 {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        char character = inputScanner.next().charAt(0);

        if ((character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z')) {
            System.out.println("Alphabet");
        } else {
            System.out.println("Not Alphabet");
        }
    }
}